import React from 'react'

function Errorpage() {
  return (
    <div>
      Page is not Found 404
    </div>
  )
}

export default Errorpage
