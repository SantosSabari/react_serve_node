import React, { useState } from 'react'


function Dashboard() {

  

  // const [users, setUser] = useState([]);
  
  // setUser(data.users)

  
  return (<>
  <h2>We are</h2>
  </>
    
  )
}

export default Dashboard
