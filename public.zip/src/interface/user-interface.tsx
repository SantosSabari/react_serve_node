export interface User{
    id?:number,
    username:string,
    email:string,
    country:string,
    city:string,
    age:string
}